from website import create_app


application, socketio = create_app()

if __name__ == "__main__":
    socketio.run(application)